# memory-paging-simulation

A simple college project to simulate how memory paging works using [Chart.js](https://github.com/chartjs/Chart.js).

## Things you likely need to know

* You do NOT need Node.js to run this project. Just drop `public` directory wherever you want and open `public/index.html` in your browser.

* Some phrases in the codes are written in Bahasa Indonesia.

* `public/js/index.js` is using ECMAScript 5 (as opposed to ECMAScript 6 in the backend) to improve compatibility with older browers (tested with IE 11 and should also work with IE 9).
